package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EmptyTest {

	Town newTown = new Town(3,4);
	Empty empty = new Empty(newTown, 2, 1);
	
	//Tests if the method who returns the correct state Empty.
	@Test
	void test() {
		assertEquals(empty.who(), State.EMPTY);
	}
	@Test
	public void test2() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.grid[1][0].next(t).who(), State.CASUAL);
		
	}

}
