package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TownTest {


	@Test
	void test() {
		Town newTown = new Town(3,3);
		assertEquals(newTown.getWidth(), 3);
	}
	@Test
	public void test2() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.getWidth(), 4);
		
	}
	@Test
	public void test3() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.getLength(), 4);
		
	}
}
