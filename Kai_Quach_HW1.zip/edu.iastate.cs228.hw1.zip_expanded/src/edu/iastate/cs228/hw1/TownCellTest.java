package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TownCellTest {
	Town newTown = new Town(4,4);
	

	@Test
	void test() { // checks if position 0,0 from the given grid is outage.
		newTown.randomInit(10);
		assertEquals(newTown.grid[0][0].who(), State.OUTAGE);
	}
	@Test
	public void test2() { // checks if next is working properly based off of the example pdf
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.grid[2][2].next(t).who(), State.EMPTY);
		
	}
}
