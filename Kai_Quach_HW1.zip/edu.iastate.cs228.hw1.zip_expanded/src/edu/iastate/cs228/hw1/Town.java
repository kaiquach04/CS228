package edu.iastate.cs228.hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;


/**
 *  @author Kai M Quach
 *
 */
public class Town{
	
	private int length, width;  //Row and col (first and second indices)
	public TownCell[][] grid;
	
	/**
	 * Constructor to be used when user wants to generate grid randomly, with the given seed.
	 * This constructor does not populate each cell of the grid (but should assign a 2D array to it).
	 * @param length
	 * @param width
	 */
	public Town(int length, int width) {
		this.length = length;
		this.width = width;
		grid = new TownCell[width][length];
	}
	
	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of catching it.
	 * Ensure that you close any resources (like file or scanner) which is opened in this function.
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		File file = new File(inputFileName);
		Scanner scan = new Scanner(file);
		width = scan.nextInt();
		length = scan.nextInt();
		grid = new TownCell[width][length];
		while (scan.hasNextLine()) {
			scan.nextLine();
			for (int i = 0; i < width; i++) {
				for (int j = 0; j < length; j++) {
					String val = scan.next();
					if (val.equals("R")) {
						grid[i][j] = new Reseller(Town.this,i, j);
					}
					else if (val.equals("E")) {
						grid[i][j] = new Empty(Town.this, i, j);
					}
					else if (val.equals("C")) {
						grid[i][j] = new Casual(Town.this, i, j);
					}
					else if (val.equals("O")) {
						grid[i][j] = new Outage(Town.this, i, j);
					}
					else if (val.equals("S")) {
						grid[i][j] = new Streamer(Town.this, i, j);
					}
				}
			}
		}
		scan.close();
	}
	/**
	 * Returns width of the grid.
	 * @return
	 */
	public int getWidth() {
		return width;
	}
	
	/**
	 * Returns length of the grid.
	 * @return
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Initialize the grid by randomly assigning cell with one of the following class object:
	 * Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				int randomValue = rand.nextInt(5);
				if (randomValue == 0) {
					grid[i][j] = new Reseller(Town.this, i, j);
				}
				else if (randomValue == 1) {
					grid[i][j] = new Empty(Town.this, i, j);
				}
				else if (randomValue == 2) {
					grid[i][j] = new Casual(Town.this, i, j);
				}
				else if (randomValue == 3) {
					grid[i][j] = new Outage(Town.this, i, j);
				}
				else if (randomValue == 4) {
					grid[i][j] = new Streamer(Town.this, i, j);
				}
			}
		}
		
	}
	
	/**
	 * Output the town grid. For each square, output the first letter of the cell type.
	 * Each letter should be separated either by a single space or a tab.
	 * And each row should be in a new line. There should not be any extra line between 
	 * the rows.
	 */
	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				if (grid[i][j].who() == State.EMPTY) {
					s += "E ";
				}
				else if (grid[i][j].who() == State.RESELLER) {
					s += "R ";
				}
				else if (grid[i][j].who() == State.CASUAL) {
					s += "C ";
				}
				else if (grid[i][j].who() == State.STREAMER) {
					s += "S ";
				}
				else if (grid[i][j].who() == State.OUTAGE) {
					s += "O ";
				}
			}
			s += "\n";
		}
		return s;
	}
}
