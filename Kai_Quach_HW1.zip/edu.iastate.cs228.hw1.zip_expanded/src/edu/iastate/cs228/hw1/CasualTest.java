package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CasualTest {


	
	//Tests if the method who returns the correct state Casual.
	@Test
	void test() {
		Town newTown = new Town(3,4);
		Casual cas = new Casual(newTown, 2, 1);
		assertEquals(cas.who(), State.CASUAL);
	}
	@Test
	public void test2() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.grid[1][2].next(t).who(), State.OUTAGE);
		
	}
}
