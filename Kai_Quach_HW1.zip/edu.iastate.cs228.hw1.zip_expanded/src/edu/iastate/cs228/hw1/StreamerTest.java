package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class StreamerTest {

	Town newTown = new Town(3,4);
	Streamer s = new Streamer(newTown, 2, 1);
	
	//Tests if the method who returns the correct state Streamer.
	@Test
	void test() {
		assertEquals(s.who(), State.STREAMER);
	}
	@Test
	public void test2() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.grid[2][1].next(t).who(), State.OUTAGE);
		
	}

}
