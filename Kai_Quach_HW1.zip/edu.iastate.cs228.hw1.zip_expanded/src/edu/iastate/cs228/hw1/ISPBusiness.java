package edu.iastate.cs228.hw1;
import java.io.FileNotFoundException;
import java.util.Scanner;


/**
 * @author Kai M Quach
 *
 * The ISPBusiness class performs simulation over a grid 
 * plain with cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {
	
	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());
		for (int i = 0; i < tNew.getWidth(); i++) {
			for (int j = 0; j < tNew.getLength(); j++) {
				tNew.grid[i][j] = tOld.grid[i][j].next(tNew);
			}
		}
		
		return tNew;
	}
	
	/**
	 * Returns the profit for the current state in the town grid.
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		int count = 0;
		for (int i = 0; i < town.grid.length; i++) {
			for (int j = 0; j < town.grid[i].length; j++) {
				if (town.grid[i][j].who().equals(State.CASUAL)) {
					count++;
				}
			}
		}
		
		return count;
	}
	

	/**
	 *  Main method. Interact with the user and ask if user wants to specify elements of grid
	 *  via an input file (option: 1) or wants to generate it randomly (option: 2).
	 *  
	 *  Depending on the user choice, create the Town object using respective constructor and
	 *  if user choice is to populate it randomly, then populate the grid here.
	 *  
	 *  Finally: For 12 billing cycle calculate the profit and update town object (for each cycle).
	 *  Print the final profit in terms of %. You should print the profit percentage
	 *  with two digits after the decimal point:  Example if profit is 35.5600004, your output
	 *  should be:
	 *
	 *	35.56%
	 *  
	 * Note that this method does not throw any exception, so you need to handle all the exceptions
	 * in it.
	 * 
	 * @param args
	 * @throws FileNotFoundException 
	 * 
	 */
	public static void main(String []args) throws FileNotFoundException { // Added filenotfound for files
		Scanner scan = new Scanner(System.in);
		System.out.println("How to populate grid (type 1 or 2). 1: from a file. 2: randomly with seed.");
		int input = scan.nextInt();
		int rows, cols, seed;
		
		Town newTown = null;
		if (input == 2) {
			System.out.println("Provide rows, cols, and seed integer");
			System.out.print("Please enter row: ");
			rows = scan.nextInt();
			System.out.println();
			System.out.print("Please enter column: ");
			cols = scan.nextInt();
			System.out.println();
			System.out.print("Please enter Seed: ");
			seed = scan.nextInt();
			newTown = new Town(cols, rows);
			newTown.randomInit(seed);
			
			
		}
		else if (input == 1) {
			System.out.println("Please provide file name ");
			String file = scan.next();
			newTown = new Town(file);
		}
		int profit = 0;
		double profitGain = 0;
		int itr = 1;
		for (int i = 0; i < 12; i++) {
			System.out.println(newTown.toString());
			profit = getProfit(newTown);
			profitGain += (getProfit(newTown) / ((double) newTown.getWidth() *newTown.getLength())) * 100;
			System.out.println("Profit: " + profit);
			System.out.println("After itr: " + itr);
			itr++;
			newTown = updatePlain(newTown);
			
		}
		
		profitGain = profitGain / 12;
		System.out.println("Profit: " + profitGain + "%");
		
	}
}
