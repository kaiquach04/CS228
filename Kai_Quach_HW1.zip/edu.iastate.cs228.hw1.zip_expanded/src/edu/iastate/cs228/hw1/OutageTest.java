package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class OutageTest {

		Town newTown = new Town(3,4);
		Outage outage = new Outage(newTown, 0, 3);
	@Test
	void test() { //Tests if the method who returns the correct state Outage.
		assertEquals(outage.who(), State.OUTAGE);
	}
	
	@Test
	public void test2() {
		Town t = new Town(4,4);
		t.randomInit(10);
		assertEquals(t.grid[0][0].next(t).who(), State.EMPTY);
		
	}

}
