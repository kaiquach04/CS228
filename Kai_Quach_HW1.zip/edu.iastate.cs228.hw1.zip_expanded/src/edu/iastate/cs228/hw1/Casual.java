package edu.iastate.cs228.hw1;

public class Casual extends TownCell {
	
	public Casual(Town t, int r, int c) {
		super(t, r, c);
		
	}
	@Override
	public State who() {
		return State.CASUAL;
	}

	@Override
	public TownCell next(Town tNew) {
		int[] census = new int[NUM_CELL_TYPE];
		census(census);
		
        if(census[OUTAGE] + census[EMPTY] <= 1){
            return new Reseller(tNew,row,col);
        }
        else if(census[RESELLER] > 0)
        {
            return new Outage(tNew,row,col);
        }
        else if(census[STREAMER] > 0 || census[CASUAL] >= 5)
        {
            return new Streamer(tNew,row,col);
        }
        else
        {
            return new Casual(tNew,row,col);
        }
	}

}
