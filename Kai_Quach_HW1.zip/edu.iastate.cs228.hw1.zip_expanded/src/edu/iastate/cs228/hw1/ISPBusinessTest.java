package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ISPBusinessTest {

		Town newTown = new Town(3,4);

	@Test
	void test() { //Checks to see if the values match based off of profit.
		newTown.randomInit(10);
		assertEquals(ISPBusiness.getProfit(newTown), 1);
	}
	@Test
	public void test2() {
		Town t = new Town(2,2);
		t.grid[0][0] = new Empty(t, 0, 0);
		t.grid[0][1] = new Empty(t, 0, 1);
		t.grid[1][0] = new Casual(t, 1, 0);
		t.grid[1][1] = new Casual(t, 1, 1);
		assertEquals(2, ISPBusiness.getProfit(t));
	}
	@Test
	public void test3() {
		Town t = new Town(4,4);
		t.randomInit(10);
		t = ISPBusiness.updatePlain(t);
		assertEquals(t.grid[0][0].who(), State.EMPTY);
	}
}
