package edu.iastate.cs228.hw2;

import java.io.File;

/**
 * 
 * @author 
 *
 */

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.InputMismatchException;
import java.util.Scanner;
/*
 * @author Kai Minh Quach
 */

/**
 * 
 * This class sorts all the points in an array of 2D points to determine a reference point whose x and y 
 * coordinates are respectively the medians of the x and y coordinates of the original points. 
 * 
 * It records the employed sorting algorithm as well as the sorting time for comparison. 
 *
 */
public class PointScanner  
{
	private Point[] points; 
	
	private Point medianCoordinatePoint;  // point whose x and y coordinates are respectively the medians of 
	                                      // the x coordinates and y coordinates of those points in the array points[].
	private Algorithm sortingAlgorithm;    
	
	String file;	
	protected long scanTime; 	       // execution time in nanoseconds. 
	
	/**
	 * This constructor accepts an array of points and one of the four sorting algorithms as input. Copy 
	 * the points into the array points[].
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException
	{
		if (pts == null || pts.length == 0) { // checks the conditionals required
			throw new IllegalArgumentException();
		}
		else { // else, assigns the param variables to the private variables
			points = pts;
			sortingAlgorithm = algo;
		}
	}

	
	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param  inputFileName
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException   if the input file contains an odd number of integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException
	{
		int count = 0; // keeps track if the input file contains an odd number of integers.
		sortingAlgorithm = algo; // assigns the private variable.
		
		try
		{
			file = inputFileName;
			File files = new File(file);
			Scanner scan = new Scanner(files);
			
			int p = 0; // placeholder so that the indexes can go to the next int val
			while (scan.hasNext()) {
				p = scan.nextInt();
				count++;
			}
			scan.close();
			if (count % 2 != 0) {
				throw new InputMismatchException();
			}
			points = new Point[count / 2];
			Scanner realScan = new Scanner(files);
			int i = 0; // iterates thru the indexes.
			while (realScan.hasNext()) {
				int x = realScan.nextInt();
				int y = realScan.nextInt();
				points[i] = new Point(x,y); // assigns the points (x,y) and puts into the array.
				i++;
			}
			realScan.close();
			
			
		}
		catch (FileNotFoundException e){
			throw new FileNotFoundException();
		}
		
	}

	
	/**
	 * Carry out two rounds of sorting using the algorithm designated by sortingAlgorithm as follows:  
	 *    
	 *     a) Sort points[] by the x-coordinate to get the median x-coordinate. 
	 *     b) Sort points[] again by the y-coordinate to get the median y-coordinate.
	 *     c) Construct medianCoordinatePoint using the obtained median x- and y-coordinates.     
	 *  
	 * Based on the value of sortingAlgorithm, create an object of SelectionSorter, InsertionSorter, MergeSorter,
	 * or QuickSorter to carry out sorting.       
	 * @param algo
	 * @return
	 */
	public void scan()
	{
		
		AbstractSorter aSorter = null; // initialize aSorter 
		long start;
		long end; // These start and end variables holds the values to keep track of the total time when subtracted for x or y.
		
		// create an object to be referenced by aSorter according to sortingAlgorithm. for each of the two 
		// rounds of sorting, have aSorter do the following: 
		// 
		//     a) call setComparator() with an argument 0 or 1. 
		//
		//     b) call sort(). 		
		// 
		//     c) use a new Point object to store the coordinates of the medianCoordinatePoint
		//
		//     d) set the medianCoordinatePoint reference to the object with the correct coordinates.
		//
		//     e) sum up the times spent on the two sorting rounds and set the instance variable scanTime. 
		
		if (sortingAlgorithm == Algorithm.SelectionSort) {
			aSorter = new SelectionSorter(points);
		}
		if (sortingAlgorithm == Algorithm.InsertionSort) {
			aSorter = new InsertionSorter(points);
		}
		if (sortingAlgorithm == Algorithm.MergeSort) {
			aSorter = new MergeSorter(points);
		}
		if (sortingAlgorithm == Algorithm.QuickSort) {
			aSorter = new QuickSorter(points);
		}
		// Setting the comparator for 0 as in X.
		aSorter.setComparator(0);
		
		start = System.nanoTime();
		aSorter.sort();
		end = System.nanoTime();
		long x = end - start;
		
		int medX = aSorter.getMedian().getX();
		//Now this is for Y
		aSorter.setComparator(1);
		start = System.nanoTime();
		aSorter.sort();
		end = System.nanoTime();
		long y = end - start;
		
		scanTime = x + y;
		
		int medY = aSorter.getMedian().getY();
		
		medianCoordinatePoint = new Point(medX, medY);
	}
	
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the project description. 
	 */
	public String stats()
	{
		String sort = "";
		//checks what type of algo is used for that point then creates a string for it.
		if (sortingAlgorithm == Algorithm.SelectionSort) {
			sort = "SelectionSort   " + points.length + "	  " + scanTime;
		}
		if (sortingAlgorithm == Algorithm.InsertionSort) {
			sort = "InsertionSort   " + points.length + "	  " + scanTime;
		}
		if (sortingAlgorithm == Algorithm.MergeSort) {
			sort = "MergeSort       " + points.length + "	  " + scanTime;
		}
		if (sortingAlgorithm == Algorithm.QuickSort) {
			sort = "QuickSort       " + points.length + "	  " + scanTime;
		}
		
		return sort;
	}
	
	
	/**
	 * Write MCP after a call to scan(),  in the format "MCP: (x, y)"   The x and y coordinates of the point are displayed on the same line with exactly one blank space 
	 * in between. 
	 */
	@Override
	public String toString()
	{
		return medianCoordinatePoint.toString(); 
		
	}

	
	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName. The format 
	 * of data in the file is the same as printed out from toString().  The file can help you verify 
	 * the full correctness of a sorting result and debug the underlying algorithm. 
	 * 
	 * @throws FileNotFoundException
	 */
	public void writeMCPToFile() throws FileNotFoundException
	{
		try {
			FileWriter file = new FileWriter(this.file);
			file.write(toString());
			file.close();
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
	}	

	

		
}
