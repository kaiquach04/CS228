package edu.iastate.cs228.hw2;

/**
 *  
 * @author Kai Minh Quach
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner; 
import java.util.Random; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Use them as coordinates to construct points.  Scan these points with respect to their 
	 * median coordinate point four times, each time using a different sorting algorithm.  
	 * 
	 * @param args
	 **/
	public static void main(String[] args) throws FileNotFoundException
	{		
		// TODO 
		// 
		// Conducts multiple rounds of comparison of four sorting algorithms.  Within each round, 
		// set up scanning as follows: 
		// 
		//    a) If asked to scan random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		// 
		//    b) Reassigns to the array scanners[] (declared below) the references to four new 
		//       PointScanner objects, which are created using four different values  
		//       of the Algorithm type:  SelectionSort, InsertionSort, MergeSort and QuickSort. 
		// 
		// 	
		// For each input of points, do the following. 
		// 
		//     a) Initialize the array scanners[].  
		//
		//     b) Iterate through the array scanners[], and have every scanner call the scan() 
		//        method in the PointScanner class.  
		//
		//     c) After all four scans are done for the input, print out the statistics table from
		//		  section 2.		
		PointScanner[] scanners = new PointScanner[4]; 
		Scanner scan = new Scanner(System.in);
		Random rand = new Random();
		
		System.out.println("Performances of Four Sorting Algorithms in Point Scanning");
		System.out.println();
		int choice = 0;
		int trial = 1;
		while (choice != 3) { // Repeatedly takes sequenced till choice is  3
			System.out.println("Keys: 1 (Random Integers) 2 (File input) 3 (Exit)");
			choice = scan.nextInt();
			
			if (choice == 1) {
				System.out.println("Trial " + trial + ": " + choice);
				System.out.println("Enter number of random points: ");
				int points = scan.nextInt();
				// initializes each index of the scanners array to random points then the type of sort.
				scanners[0] = new PointScanner(generateRandomPoints(points, rand), Algorithm.SelectionSort);
				scanners[1] = new PointScanner(generateRandomPoints(points, rand), Algorithm.InsertionSort);
				scanners[2] = new PointScanner(generateRandomPoints(points, rand), Algorithm.MergeSort);
				scanners[3] = new PointScanner(generateRandomPoints(points, rand), Algorithm.QuickSort);
				
				System.out.println("Algorithm size time (ns)");
				System.out.println("----------------------------------");
				for (int i = 0; i < scanners.length; i++) {
					scanners[i].scan();
					System.out.println(scanners[i].stats());
					// uses a for loop to scan each index and the stats from that index.
				}
				trial++; // updates the trial to count amount of times trial occurs.
			}
			else if(choice == 2) {
				System.out.println("Trial " + trial + ": " + choice);
				System.out.println("Points from a file");
				System.out.println("File name: ");
				String file = scan.next();
				// initializes each index of scanners and sets the point from the file.
				scanners[0] = new PointScanner(file, Algorithm.SelectionSort);
				scanners[1] = new PointScanner(file, Algorithm.InsertionSort);
				scanners[2] = new PointScanner(file, Algorithm.MergeSort);
				scanners[3] = new PointScanner(file, Algorithm.QuickSort);
				
				System.out.println("Algorithm size time (ns)");
				System.out.println("----------------------------------");
				for (int i = 0; i < scanners.length; i++) {
					scanners[i].scan();
					System.out.println(scanners[i].stats());
					// uses a for loop to iterate through each index of scanners array to scan and print stats.
				}
				scanners[3].writeMCPToFile();
				trial++;
			}
		}
	}
	
	
	/**
	 * This method generates a given number of random points.
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		//first checks if numpts is less than 1 to throw exception.
		if (numPts < 1) {
			throw new IllegalArgumentException();
		}
		//creating a new array that holds the newest points.
		Point[] points = new Point[numPts];
		
		for (int i = 0; i < numPts; i++) {
			Point p = new Point(rand.nextInt(101) - 50, rand.nextInt(101) - 50);
			// given in section 3, this produces the new random points
			points[i] = p;
		}
		return points;
	}
	
}
